shell.setDir('EasyPlay/')
