local controller = {}

controller.new = function()
    return function()
        while true do
            event, key = os.pullEvent("key")
            if key == keys.e then
                os.reboot()
            elseif key == keys.d then
                os.queueEvent("terminate")
            end
        end
    end
end

return controller