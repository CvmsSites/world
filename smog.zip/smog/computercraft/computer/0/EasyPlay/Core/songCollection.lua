local function download(name)
    if fs.getFreeSpace("EasyPlay/Songs") <= 10000 then error("Out of Space!") end
    local url =
        "https://github.com/thatcraniumguy/Songs/blob/master/NBS%20files/"
    url = url .. string.gsub(name, "%s+", "%%20") .. "?raw=true"
    name = string.gsub(name, "%s+", "_")
    name = "EasyPlay/Songs/" .. name
    if not fs.exists(name) then
        shell.run("//EasyPlay/easyPlay.lua download " .. url .. " " .. name)
    end
end

download("14th Song.nbs");
download("A Nightmare Before Christmas.nbs");
download("Africa.nbs");
download("Animals.nbs");
download("Another One Bites the Dust.nbs");
download("Auld Lang Syne.nbs");
download("Axel F - Beverly Hills Cop.nbs")
download("Axel F - Remastered.nbs");
download("Beat it.nbs");
download("Billie Jean.nbs");
download("Can You Feel the Love.nbs");
download("Canon in D.nbs");
download("Carol of the Bells.nbs");
download("Cat's In the Cradle.nbs");
download("Centerfold.nbs");
download("Demons.nbs");
download("Dixie Land.nbs");
download("Downtown.nbs");
download("Dream Lover.nbs");
download("Dueling Banjos.nbs");
download("Everybody Dance Now.nbs");
download("Fairy Tail Theme.nbs");
download("Flight of The Bumblebee.nbs");
download("Float On.nbs");
download("Footloose.nbs");
download("Friends in Low Places.nbs");
download("Frosty the Snowman.nbs");
download("Fugue In D Minor.nbs");
download("Fur Elise.nbs");
download("GerudoValley.nbs");
download("Ghostbusters.nbs");
download("Grandma Got Run Over by a Reindeer.nbs");
download("Guren No Yumiya.nbs");
download("Happy.nbs");
download("Hotel California.nbs");
download("I Am the Doctor.nbs");
download("In the Hall of the Mountain King.nbs");
download("Joy to the World.nbs");
download("Let It Be.nbs");
download("Levels.nbs");
download("Luigi's Mansion.nbs");
download("MortalKombat.nbs");
download("Never Gonna Give You Up.nbs");
download("Numb.nbs");
download("Nutcracker Dance of the Sugar Plum Fairies.nbs");
download("Nutcracker Russian Dance.nbs");
download("Nutcracker Waltz.nbs");
download("Ob-La-Di, Ob-La-Da.nbs");
download("Ode to Joy.nbs");
download("Pallet Town Theme.nbs");
download("Papermoon.nbs");
download("Peanut's Theme.nbs");
download("Pokemon Red-Blue Title.nbs");
download("Radioactive.nbs");
download("RainbowTylenol.nbs");
download("Reptilia.nbs");
download("Resonance.nbs");
download("Rock and Roll All Night.nbs");
download("Santeria.nbs");
download("Star Spangled Banner.nbs");
download("StarFox64Theme.nbs");
download("Steins Gate.nbs");
download("Still Alive.nbs");
download("Superstition.nbs");
if fs.getFreeSpace("EasyPlay/Songs") <= 10000 then
    error(
        "Out of space! About 300KB more are required to download the rest. Run EasyPlay/Core/songCollection.lua to resume the download.");
end
download("Sweet Child of Mine.nbs");
download("Take On Me.nbs");
download("The Entertainer.nbs");
download("The Final Countdown.nbs");
download("The Pretender.nbs");
download("Through the Fire and Flames.nbs");
download("TownMarket.nbs");
download("Want You Gone - Simplified.nbs");
download("We're not Gonna Take It.nbs");
download("Where No One Goes.nbs");
download("Wizards in Winter.nbs");