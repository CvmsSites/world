local playerslave = {}

local instinfo = dofile("EasyPlay/Core/noteinfo.lua")

playerslave.new = function(side, id, subid)
    return function()
        local speaker = peripheral.wrap(side)

        os.queueEvent("player:slaveinfo", id, subid, side)

        while true do
            local evt, p1_id, p2_subid, p3_inst, p4_note, p5_volume =
                os.pullEvent("player:slave")
            if id == p1_id and subid == p2_subid then
                local mcvolume = 3
                if p5_volume < 100 then
                    mcvolume = p5_volume / 33.333333
                end
                local mcinstr = instinfo.instnames[p3_inst + 1]
                speaker.playNote(mcinstr, mcvolume, p4_note)
            end
        end
    end
end

return playerslave