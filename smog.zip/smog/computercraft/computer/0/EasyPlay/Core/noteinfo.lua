-- Notes and instruments
local notenames = {
    "F#3", " G3", "G#3", " A3", "A#3", " B3", " C4", "C#4", " D4", "D#4", " E4",
    " F4", "F#4", " G4", "G#4", " A4", "A#4", " B4", " C5", "C#5", " D5", "D#5",
    " E5", " F5", "F#5", " G5", "G#5", " A6", "A#6", " B6", " C6", "C#6", " D6",
    "D#6", " E6", " F6", "F#6", " G6", "G#6", "A7", "A#7", " B7", " C7", "C#7",
    " D7", "D#7", " E7", " F7", "F#7", " G7", "G#7", "A8", "A#8", " B8", " C8",
    "C#8", " D8", "D#8", " E8", " F8", "F#8", " G8", "G#8", "A9", "A#9", " B9",
    " C9", "C#9", " D9", "D#9", " E9", " F9", "F#9", " G9", "G#9"
}

local instnames = {
    "harp", "bass", "basedrum", "snare", "hat", "guitar", "flute", "bell",
    "chime", "xylophone", "iron_xylophone", "cow_bell", "didgeridoo", "bit",
    "banjo", "pling"
}

return {notenames = notenames, instnames = instnames}