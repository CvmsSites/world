--[[
  playMonitor
  By SoniEx2
--]] -- 
-- fastq is no better than CCland other than for table/function support,
-- so we don't use it by default.
-- REQUIRES FASTQ
local use_fastq = false

local x = function(...)
    local args = {...} -- args table

    local monitorBaseSettings = {
        hasColor = (args[1] == "true" or args[1] == "on" or args[1] == "1"),
        title = args[2]:gsub("%_", "% "),
        -- avoid errors
        footerLeft = "",
        footerRight = ""
    }

    local playerslave = dofile("EasyPlay/Core/player_slave.lua")
    local playermonitor = dofile("EasyPlay/Core/player_monitor.lua")
    local playernbs = dofile("EasyPlay/Core/player_nbs.lua")
    local controller = dofile("EasyPlay/Core/controller.lua")

    local function play(filename, monside, ...)
        local id = os.clock() -- heh
        local subid = 1
        local maxsubid = 1
        local speakers = {...};

        local threads = {}

        table.insert(threads, controller.new())

        local monitor = peripheral.wrap(monside)
        table.insert(threads,
                     playermonitor.new(monitor, id, subid, monitorBaseSettings))

        for i, side in ipairs(speakers) do
            table.insert(threads, playerslave.new(side, id, subid))
        end

        table.insert(threads,
                     playernbs.new(id, maxsubid, filename, monitorBaseSettings))

        table.insert(threads, function()
            local count = 0
            while true do
                local evt, p1_id, p2_subid, p3_side = os.pullEvent(
                                                          "player:slaveinfo")

                monitorBaseSettings.footerLeft = #speakers ..
                                                     " speakers connected"
            end
        end)

        parallel.waitForAny(unpack(threads))
    end

    play(select(3, ...))
end

if use_fastq then
    dofile("EasyPlay/Core/fastq.lua").init(x, ...)
else
    x(...)
end