--[[
  easyPlay
  By Barnet
--]] -- --
local function download(url, name)
    local request, err = http.get(url, nil, true)
    if not request then error(err) end
    if name == "" then
        name = url
        local i = string.find(name, "/[^/]*$")
        if i ~= nil then name = string.sub(name, i + 1, string.len(name)) end
        i, j = string.find(name, ".nbs")
        if i == nil then
            i = 0
            if fs.exists("EasyPlay/Songs/Unknown.nbs") then
                repeat i = i + 1 until fs.exists(
                    "EasyPlay/Songs/Unknown_" .. i .. ".nbs")
                name = "Unknown_" .. i .. ".nbs"
            else
                name = "Unknown.nbs"
            end
        else
            name = string.sub(name, 1, j)
            if string.find(url, "open-note-block-studio") == nil then
                name = string.gsub(name, "%%20", "_")
            else
                while i ~= nil do
                    i, j = string.find(name, "%%20")
                    if i == nil then
                        i, j = string.find(name, "%%2F")
                    end
                    if i ~= nil then
                        name = string.sub(name, j + 1, string.len(name))
                    end
                end
            end
            name = name:gsub("^%l", string.upper)
        end
        name = "EasyPlay/Songs/" .. name
    end
    local file = fs.open(name, "wb")
    file.write(request.readAll())
    file.close()
    request.close()
    print("Successfully downloaded " .. name)
end

local function getSongs(songPath)
    local songs = {songPath}
    local r = {}
    for i, song in ipairs(songs) do
        if fs.isDir(song) then
            moreSongs = fs.list(song)
            for j, s in ipairs(moreSongs) do
                table.insert(songs, song .. "/" .. s)
            end
            table.insert(r, i)
        end
    end

    for i = table.maxn(r), 1, -1 do table.remove(songs, r[i]) end

    return songs
end

local function getName(song)
    local i = string.find(song, "/[^/]*$")
    if i ~= nil then
        local songName = string.sub(song, i + 1, string.len(song))
        songName = songName:gsub("^%l", string.upper)
        i = string.find(songName, "%.")
        if i ~= nil then songName = string.sub(songName, 1, i - 1) end
        return songName
    else
        return song
    end
end

local function start(songPath, option)
    local loop = option ~= nil and string.find(option, "l") ~= nil
    local shuffle = option ~= nil and string.find(option, "s") ~= nil
    local color = option ~= nil and string.find(option, "c") ~= nil

    if songPath == "" then songPath = "EasyPlay/Songs" end

    print("Press 'D' to skip a song.")
    print("Press 'E' to end the program.")

    if loop then print("Looping enabled") end

    if shuffle then print("Shuffle enabled") end

    if string.sub(songPath, 1, 1) == '.' then
        songPath = shell.dir() .. string.sub(songPath, 2)
    end
    local songs = getSongs(songPath)
    local n = table.maxn(songs)
    if n > 1 then
        print("Found " .. n .. " songs.")
        print()
    end

    repeat
        if shuffle then
            for i = table.maxn(songs), 2, -1 do
                local j = math.random(i)
                songs[i], songs[j] = songs[j], songs[i]
            end
        end

        monitor = peripheral.find("monitor")
        if monitor == nil then error("No monitor detected!") end
        monitorName = peripheral.getName(monitor)

        local speakers = ""
        local speakerCount = 0
        for i, perName in ipairs(peripheral.getNames()) do
            if string.find(perName, "speaker") then
                speakers = speakers .. perName .. " "
                speakerCount = speakerCount + 1
            end
        end

        if speakerCount == 0 then error("No speakers detected!") end

        for i, song in ipairs(songs) do
            print("Now playing " .. song .. "...")
            shell.run("Core/playnbs.lua " .. tostring(color) .. " " ..
                          getName(song) .. " " .. song .. " " .. monitorName ..
                          " " .. speakers)
            print()
        end
    until not loop
end

local function helpOption(option)
    if option == "start" then
        print("Usage: start <songPath> <option>")
        print("Start playing the nbs file or folder located at <songPath>.")
        print("Options: ")
        print("  s: shuffle")
        print("  l: loop")
        print("  c: color")
        print("If you get errors try another file.")
        print("Example: 'easyPlay start ./Songs/megalovania.nbs ls'")
    elseif option == "download" then
        print("Usage: download <url> <songName>")
        print("Download a nbs song with a http request.")
        print("You can browse https://opennbs.org/songs/ for some songs.")
        print("Keep in mind that not all of them work with this program.")
        print(
            "Example: 'easyPlay download https://firebasestorage.googleapis.com/v0/b/open-note-block-studio.appspot.com/o/users%2FLfdGva0xi3OpmzsXXjTFMreFt6g2%2Fsongs%2Fmegalovania.nbs?alt=media&token=34e1a114-608d-4638-89f3-ef2f404e9d4c megalovania.nbs")
    else
        print("Welcome to EasyPlay!")
        print(
            "To get started you can just use the 'easyPlay' command by itself without any arguments to play everything inside the 'Songs' folder.")
        print(
            "If you want a little bit more control you can use the 'start' option.")
        helpOption("start")
    end
    print()
end

local function GetArg(a)
    if a ~= nil then
        return a
    else
        return ""
    end
end

if #arg == 0 then
    start("", "ls")
else
    local option = arg[1]
    local arg1 = GetArg(arg[2])
    local arg2 = GetArg(arg[3])
    if option == "help" or option == "?" then
        helpoption(arg1)
    elseif option == "download" then
        if arg1 == "" then
            helpOption("download")
        else
            download(arg1, arg2)
        end
    elseif option == "start" then
        start(arg1, arg2)
    else
        start(option, arg1)
    end
end